package org.air;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AddFlight")
public class AddFlight extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve form data
        String flightNumber = request.getParameter("flightNumber");
        String departure = request.getParameter("departure");
        String destination = request.getParameter("destination");
        String departureTime = request.getParameter("departureTime");
        String arrivalTime = request.getParameter("arrivalTime");

        // JDBC connection parameters
        String url = "jdbc:mysql://localhost:3306/Air";
        String dbUser = "root";
        String dbPassword = "root";

        try (Connection connection = DriverManager.getConnection(url, dbUser, dbPassword)) {
            // SQL query to insert flight details into the database
            String sql = "INSERT INTO flights (flight_number, departure, destination, departure_time, arrival_time) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                // Set values for parameters in the SQL query
                statement.setString(1, flightNumber);
                statement.setString(2, departure);
                statement.setString(3, destination);
                statement.setString(4, departureTime);
                statement.setString(5, arrivalTime);
                // Execute the SQL query to insert data into the database
                int rowsInserted = statement.executeUpdate();
                if (rowsInserted > 0) {
                    // If insertion is successful, redirect back to the add flight page
                    response.sendRedirect("AddFlight.jsp");
                    response.getWriter().println("Success to add flight.");
                } else {
                    // If insertion fails, display an error message
                    response.getWriter().println("Failed to add flight.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle any SQL exceptions
            response.getWriter().println("SUccess to add flight.");
            response.getWriter().println("Failed to add flight. Please try again later.");
        }
    }
}
