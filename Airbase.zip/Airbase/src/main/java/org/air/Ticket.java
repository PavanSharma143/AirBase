package org.air;

public class Ticket {
    private String username;
    private String destination;
    private String date;

    public Ticket(String username, String destination, String date) {
        this.username = username;
        this.destination = destination;
        this.date = date;
    }

    // Getters and setters for the ticket attributes
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
