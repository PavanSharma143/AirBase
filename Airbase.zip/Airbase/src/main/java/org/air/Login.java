package org.air;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Login")
public class Login extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String user = request.getParameter("username");
        String pass = request.getParameter("password");
        String role = request.getParameter("role");
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Air", "root", "root");
            String sql = "SELECT * FROM login WHERE email=? AND password=?";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, user);
            statement.setString(2, pass);
            ResultSet executeQuery = statement.executeQuery();
            if (executeQuery.next()) {
                String email = executeQuery.getString("email");
                String password = executeQuery.getString("password");
                String person = executeQuery.getString("person");
                if (role.equals(person)) {
                    if (role.equals("User")) {
                        request.setAttribute("username", user);
                        request.getRequestDispatcher("UserDash.jsp").forward(request, response);
                    } else if (role.equals("Admin")) {
                        request.setAttribute("username", user);
                        request.getRequestDispatcher("AdminDash.jsp").forward(request, response);
                    }
                } else {
                    request.setAttribute("error", "Invalid role selected. Please try again.");
                    request.getRequestDispatcher("ResetPass.jsp").forward(request, response);
                }
            } else {
                request.setAttribute("error", "Invalid credentials. Please try again.");
                request.getRequestDispatcher("ResetPass.jsp").forward(request, response);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "An error occurred. Please try again later.");
            request.getRequestDispatcher("ResetPass.jsp").forward(request, response);
        }
    }
}
