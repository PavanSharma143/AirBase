package org.air;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DeleteFlight")
public class DeleteFlight extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String flightNumber = request.getParameter("flightNumber");
        
        // JDBC connection parameters
        String url = "jdbc:mysql://localhost:3306/Air";
        String dbUser = "root";
        String dbPassword = "root";

        try (Connection connection = DriverManager.getConnection(url, dbUser, dbPassword)) {
            // SQL query to delete flight from the database
            String sql = "DELETE FROM flights WHERE flight_number=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, flightNumber);
                // Execute the SQL query to delete the flight
                int rowsDeleted = statement.executeUpdate();
                if (rowsDeleted > 0) {
                    response.sendRedirect("AdminDash.jsp");
                    response.getWriter().println("<script>");
                    response.getWriter().println("alert('Successfully Deleted.');");
                    response.getWriter().println("</script>");
                } else {
                    response.getWriter().println("<script>");
                    response.getWriter().println("alert('Failed to delete flight. Please try again later.');");
                    response.getWriter().println("window.location.href = 'AdminDash.jsp';");
                    response.getWriter().println("</script>");
                }

            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Failed to delete flight. Please try again later.");
        }
    }
}
