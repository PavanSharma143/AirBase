package org.air;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ViewBookings")
public class VIewBooking extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String url = "jdbc:mysql://localhost:3306/Air";
        String dbUser = "root";
        String dbPassword = "root";

        List<Ticket> bookings = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(url, dbUser, dbPassword)) {
            String sql = "SELECT * FROM tickets";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                ResultSet resultSet = statement.executeQuery();
                while (resultSet.next()) {
                    String username = resultSet.getString("username");
                    String destination = resultSet.getString("destination");
                    String date = resultSet.getString("date");
                    Ticket booking = new Ticket(username, destination, date);
                    bookings.add(booking);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Failed to retrieve bookings. Please try again later.");
            return;
        }

        request.setAttribute("bookings", bookings);
        request.getRequestDispatcher("viewBooking.jsp").forward(request, response);
    }
}
