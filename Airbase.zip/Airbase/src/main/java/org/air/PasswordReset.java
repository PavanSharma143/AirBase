package org.air;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/PasswordReset")
public class PasswordReset extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String newPassword = request.getParameter("newPassword");
        String confirmPassword = request.getParameter("confirmPassword");

        // Validation: Ensure passwords match
        if (!newPassword.equals(confirmPassword)) {
            response.getWriter().println("Passwords do not match.");
            return;
        }

        // JDBC connection parameters
        String url = "jdbc:mysql://localhost:3306/Air";
        String dbUser = "root";
        String dbPassword = "root";

        try (Connection connection = DriverManager.getConnection(url, dbUser, dbPassword)) {
            String sql = "UPDATE users SET password = ? WHERE username = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, newPassword);
                statement.setString(2, username);
                int rowsUpdated = statement.executeUpdate();
                if (rowsUpdated > 0) {
                	
                    response.sendRedirect("Home.jsp");
                } else {
                    response.getWriter().println("Failed to reset password.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Failed to reset password. Please try again later.");
        }
    }
}
