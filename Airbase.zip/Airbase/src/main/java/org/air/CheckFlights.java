package org.air;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CheckFlights")
public class CheckFlights extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Flight> flights = new ArrayList<>();
        String url = "jdbc:mysql://localhost:3306/Air";
        String dbUser = "root";
        String dbPassword = "root";

        try (Connection connection = DriverManager.getConnection(url, dbUser, dbPassword)) {
            String sql = "SELECT * FROM flights";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                ResultSet resultSet = statement.executeQuery();
                while (resultSet.next()) {
                    String flightNumber = resultSet.getString("flightNumber");
                    String departure = resultSet.getString("departure");
                    String destination = resultSet.getString("destination");
                    String departureTime = resultSet.getString("departureTime");
                    String arrivalTime = resultSet.getString("arrivalTime");
                    Flight flight = new Flight(flightNumber, departure, destination, departureTime, arrivalTime);
                    flights.add(flight);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        request.setAttribute("flights", flights);
        request.getRequestDispatcher("checkFlights.jsp").forward(request, response);
    }
}
