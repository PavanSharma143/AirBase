package org.air;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BookTicket")
public class BookTicket extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve parameters from the request
        String username = request.getParameter("username");
        String destination = request.getParameter("destination");
        String date = request.getParameter("date");

        // JDBC connection parameters
        String url = "jdbc:mysql://localhost:3306/Air";
        String dbUser = "root";
        String dbPassword = "root";

        try (Connection connection = DriverManager.getConnection(url, dbUser, dbPassword)) {
            // SQL query to insert ticket information
            String sql = "INSERT INTO tickets (username, destination, date) VALUES (?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                // Set values for parameters in the SQL query
                statement.setString(1, username);
                statement.setString(2, destination);
                statement.setString(3, date);
                // Execute the SQL query to insert data into the database
                int rowsInserted = statement.executeUpdate();
                if (rowsInserted > 0) {
                    // If insertion is successful, redirect to ticketConfirmation.jsp
                    response.sendRedirect("TicketConfirmation.jsp");
                } else {
                    // If insertion fails, display an error message
                    response.getWriter().println("Failed to book ticket.");
                }
            }
        } catch (SQLException e) {
            // Catch any SQL exceptions and print stack trace
            e.printStackTrace();
            // Display an error message if there's an issue with the database connection
            response.getWriter().println("Failed to book ticket. Please try again later.");
        }
    }
}
