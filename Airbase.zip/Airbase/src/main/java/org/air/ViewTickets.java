package org.air;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ViewTickets")
public class ViewTickets extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // JDBC connection parameters
        String url = "jdbc:mysql://localhost:3306/Air";
        String dbUser = "root";
        String dbPassword = "root";

        // List to hold ticket objects
        List<Ticket> tickets = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(url, dbUser, dbPassword)) {
            // SQL query to select all tickets from the database
            String sql = "SELECT * FROM tickets";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                // Execute the SQL query
                ResultSet resultSet = statement.executeQuery();
                // Iterate through the result set and create Ticket objects
                while (resultSet.next()) {
                    String username = resultSet.getString("username");
                    String destination = resultSet.getString("destination");
                    String date = resultSet.getString("date");
                    // Create a new Ticket object
                    Ticket ticket = new Ticket(username, destination, date);
                    // Add the ticket to the list
                    tickets.add(ticket);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle any SQL exceptions
            response.getWriter().println("Failed to retrieve tickets. Please try again later.");
            return;
        }

        // Set the list of tickets as an attribute in the request
        request.setAttribute("tickets", tickets);
        // Forward the request to ticketConfirmation.jsp for display
        request.getRequestDispatcher("ticketConfirmation.jsp").forward(request, response);
    }
}
